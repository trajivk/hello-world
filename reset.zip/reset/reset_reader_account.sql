/*--------------------------------------------------------------------------------
  RESET READER ACCOUNT V2

  Run this in the reader account to reset the demo environment. This script also
  sets up the account initially.

  Author:   Alan Eldridge
  Updated:  29 June 2019 - aeldridge - granted import share to sysadmin

  #reset #reader #managed_account
--------------------------------------------------------------------------------*/

use role accountadmin;

drop database if exists citibike;
grant import share on account to role sysadmin;

use role sysadmin;

create or replace warehouse nycha_wh with warehouse_size = 'medium' auto_suspend = 300 initially_suspended = true;
