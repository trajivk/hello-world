/*--------------------------------------------------------------------------------
  READY DEMO ACCOUNT V2

  This script quickly loads all the table data and creates the views. It is a
  shortcut to be able to run the optional vignettes.

  Run this in the demo account.

  Author:   Alan Eldridge
  Updated:  29 June 2019

  #reset #quickstart #ready
--------------------------------------------------------------------------------*/

use role dba_citibike;
create warehouse if not exists load_wh with warehouse_size = 'xlarge' auto_suspend = 300 initially_suspended = true;
alter warehouse if  exists load_wh set warehouse_size = 'xlarge';
use warehouse load_wh;
use schema citibike.public;

-- load the tables
create or replace table programs as select * from citibike_reset_v2.public.programs;
create or replace table stations as select * from citibike_reset_v2.public.stations;
create or replace table trips as select * from citibike_reset_v2.public.trips;
create or replace table weather (v variant, t timestamp_ntz) as
  (select v, convert_timezone('UTC', 'US/Eastern', v:time::timestamp_ntz) from citibike_reset_v2.public.weather);


-- create the trips view
create or replace secure view trips_vw as
select tripduration, starttime, stoptime,
       ss.station_name start_station_name, ss.station_latitude start_station_latitude, ss.station_longitude start_station_longitude,
       es.station_name end_station_name, es.station_latitude end_station_latitude, es.station_longitude end_station_longitude,
       bikeid, usertype, birth_year, gender, program_name
from trips t inner join stations ss on t.start_station_id = ss.station_id
             inner join stations es on t.end_station_id = es.station_id
             inner join programs p on t.program_id = p.program_id;


-- create the trips + weather view
create or replace secure view trips_weather_vw as (
  with
    t as (
      select date_trunc(hour, starttime) starttime, date_trunc(hour, stoptime) stoptime,
        tripduration, start_station_name, start_station_latitude, start_station_longitude,
        end_station_name, end_station_latitude, end_station_longitude, bikeid, usertype,
        birth_year, gender, program_name
      from trips_vw),
    w as (
      select date_trunc(hour, t)                observation_time
        ,avg(degKtoC(v:main.temp::float))       temp_avg_c
        ,min(degKtoC(v:main.temp_min::float))   temp_min_c
        ,max(degKtoC(v:main.temp_max::float))   temp_max_c
        ,avg(degKtoF(v:main.temp::float))       temp_avg_f
        ,min(degKtoF(v:main.temp_min::float))   temp_min_f
        ,max(degKtoF(v:main.temp_max::float))   temp_max_f
        ,avg(v:wind.deg::float)                 wind_dir
        ,avg(v:wind.speed::float)               wind_speed
      from weather
      where v:city.id::int = 5128638
      group by 1)
  select *
  from t left outer join w on t.starttime = w.observation_time);

-- clean up
alter warehouse load_wh set warehouse_size = 'medium';
