/*--------------------------------------------------------------------------------
  RESET DEMO ACCOUNT V2

  Run this in the demo account to reset the demo environment. This script also
  sets up the account initially.

  Author:   Alan Eldridge
  Updated:  29 June 2019 - aeldridge - added security table for data sharing

  #reset #stored_procedure #trips #weather #udf #query_tag
--------------------------------------------------------------------------------*/

use role dba_citibike;

drop share if exists citibike;
drop warehouse if exists load_wh;
drop warehouse if exists dev_wh;
drop warehouse if exists task_wh;
drop database if exists citibike_dev;

-- create a warehouse for use in the reset script
create or replace warehouse reset_wh
  warehouse_size = 'xlarge' max_cluster_count = 1 initially_suspended = true;

/*--------------------------------------------------------------------------------
  Connect to the reset share.
--------------------------------------------------------------------------------*/

use role accountadmin;

create or replace database citibike_reset_v2 from share citibike_sfc.citibike_reset_v2 comment='Reset DB for Citibike demo.';
grant imported privileges on database citibike_reset_v2 to role dba_citibike;

create or replace database citibike_big_v2 from share citibike_sfc.citibike_big_v2 comment='Bigger version of Citibike - ~1Bn trips & 600K weather records.';
grant imported privileges on database citibike_big_v2 to role dba_citibike;
grant imported privileges on database citibike_big_v2 to role analyst_citibike;

use role dba_citibike;

/*--------------------------------------------------------------------------------
  Recreate the demo database in a clean state.
--------------------------------------------------------------------------------*/

create or replace database citibike;
use schema citibike.public;

-- create the csv file format
create or replace file format csv_no_header type='csv'
  compression = 'auto' field_delimiter = ',' skip_header = 0
  field_optionally_enclosed_by = '"' null_if = ('NULL','\\N','\N', '');

-- create the json file format
create or replace file format json type='json'
  compression = 'auto' enable_octal = false allow_duplicate = false
  strip_outer_array = false strip_null_values = false ignore_utf8_errors = false;


/*--------------------------------------------------------------------------------
  Create the stored procs used throughout the demo.
--------------------------------------------------------------------------------*/

-- stored proc to unload data into partitions
create or replace procedure UnloadToPartitions (PARTITION_COL STRING, PARTITION_TABLE STRING,
                                                DATA_COL STRING, DATA_TABLE STRING,
                                                TARGET_STAGE STRING, FILE_FORMAT STRING,
                                                START_POS STRING, END_POS STRING)
  returns float
  language javascript
  strict
as
$$
  var counter = 0;

  // list the partition values
  var partitions = snowflake.execute({ sqlText: "select distinct " + PARTITION_COL + " from " + PARTITION_TABLE +
                                                " where " + PARTITION_COL + " >= '" + START_POS +
                                                "' and " + PARTITION_COL + " <= '" + END_POS +
                                                "' order by 1;" });

  // for each partition
  while (partitions.next())
  {
    var partition = partitions.getColumnValue(1);
    var unload_qry = snowflake.execute({ sqlText: "copy into " + TARGET_STAGE + "/" + partition +
                                         "/ from (select " + DATA_COL + " from " + DATA_TABLE +
                                         " where " + PARTITION_COL + " = '" + partition +
                                         "') file_format = " + FILE_FORMAT + ";" });
    counter++;
}
  return counter;
$$;


-- stored proc to run a query multiple times
create or replace procedure RunQueryNTimes (QRY STRING, N FLOAT)
  returns float
  language javascript
  strict
as
$$
  duration = 0;
  for (i = 0; i < N; i++) {
    startTime = Date.now();
    snowflake.execute({sqlText: QRY});
    endTime = Date.now()
    duration += endTime-startTime;
  }
  return duration/N;
$$;

-- UDF to convert Kelvin to Celcius
create or replace function degKtoC(k float)
returns float
as
$$
  k - 273.15
$$;

-- UDF to convert Kelvin to Farenheit
create or replace function degKtoF(k float)
returns float
as
$$
  k * 9 / 5 - 459.67
$$;


/*--------------------------------------------------------------------------------
  Create the initial tables - TRIPS, PROGRAMS and STATIONS.
  These are pulled from the publisher account in the region.
--------------------------------------------------------------------------------*/

create or replace table programs as select * from citibike_reset_v2.public.programs;
create or replace table stations as select * from citibike_reset_v2.public.stations;


/*--------------------------------------------------------------------------------
  Create the demo load stages for TRIPS and WEATHER. These are internal stages
  for each demo account, and we unload the data from the publisher account into
  them so they are ready to load from.
--------------------------------------------------------------------------------*/

create or replace stage weather file_format=json;
create or replace stage trips file_format=csv_no_header;

  -- unload the TRIPS table partitioned by year
call UnloadToPartitions('year(starttime)',
                        'citibike_reset_v2.public.trips',
                        '*',
                        'citibike_reset_v2.public.trips',
                        '@trips',
                        'csv_no_header',
                        '0000', '9999');

ls @trips;

-- unload the WEATHER table
call UnloadToPartitions('year(v:time::timestamp)',
                        'citibike_reset_v2.public.weather',
                        'v',
                        'citibike_reset_v2.public.weather',
                        '@weather',
                        'json',
                        '0000', '9999');

ls @weather;

/*--------------------------------------------------------------------------------
  Grant access to Jane - the analyst_citibike role
--------------------------------------------------------------------------------*/

use role accountadmin;
grant usage on database citibike to role analyst_citibike;
grant usage on schema citibike.public to role analyst_citibike;
grant select on future tables in schema citibike.public to role analyst_citibike;
grant select on future views in schema citibike.public to role analyst_citibike;
grant execute task on account to role dba_citibike;
use role dba_citibike;


/*--------------------------------------------------------------------------------
  Set up the security table with rules for the managed accounts
--------------------------------------------------------------------------------*/

show managed accounts;

create or replace table security (name string, account string, filter string) as
  select $1, $4, '%' || $1 || '%' from table(result_scan(last_query_id()));

insert into security values ('Publisher Account', current_account(), '%');


/*--------------------------------------------------------------------------------
  Set up the Tableau query performance view
--------------------------------------------------------------------------------*/

create or replace view tableau_query_history as
  select *
  from table(citibike.information_schema.query_history_by_user('JANE', dateadd('minutes',-60,current_timestamp()),current_timestamp(), 500))
  where query_tag='QueryFromTableau';


/*--------------------------------------------------------------------------------
  Clean up
--------------------------------------------------------------------------------*/

drop warehouse reset_wh;
