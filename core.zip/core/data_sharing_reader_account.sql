/*--------------------------------------------------------------------------------

  DATA SHARING READER ACCOUNT V2

  #3b in the core demo flow.
  Run this in your NYCHA reader account.

  This is the reader side of the data sharing demo.
  We consume the incoming share and query the data. We ask for the null data
  to be cleaned up. Then we query the restricted share.

  Author:   Alan Eldridge
  Updated:  29 June 2019 - aeldridge - modified to not require customisation per account

  #datasharing #consumer #managed_account #secure
--------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------
  Connect to the incoming share using the Shares tab
--------------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------------
  Use a warehouse in this account to query data from the publisher account
--------------------------------------------------------------------------------*/

use warehouse nycha_wh;
use schema citibike.public;

-- query the shared data
select count(*) from trips_weather_vw;

select program_name, count(*) as "Num Trips"
  from trips_weather_vw
  group by 1
  order by 2 desc;


/*--------------------------------------------------------------------------------
  Get rid of the nulls
  <==
  <== switch back to the publisher account and clean up the data
  <==
--------------------------------------------------------------------------------*/

-- rerun the same query - now the nulls are gone
select program_name, count(*) as "Num Trips"
  from trips_weather_vw
  group by 1
  order by 2 desc;


/*--------------------------------------------------------------------------------
  We should only be able to see our data - not all housing authorities
  <==
  <== switch back to the publisher account and lock things down
  <==
--------------------------------------------------------------------------------*/

-- query the new shared data
select count(*) from secure_trips_weather_vw;

-- can only see the rows for this account
-- note there is no WHERE clause - security is enforced by publisher
select program_name, count(*) as "Num Trips"
  from secure_trips_weather_vw
  group by 1
  order by 2 desc;

-- can only see permitted columns from the source view
-- note the data obfuscation in action
select *
  from secure_trips_weather_vw
  limit 100;
