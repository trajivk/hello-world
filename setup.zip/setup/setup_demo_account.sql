/*--------------------------------------------------------------------------------
  SETUP DEMO ACCOUNT V2

  Setup script for the demo account. Creates the users (john & jane), roles
  (analyst_citibike & dba_citibike) and analyst warehouses for the Citibike demo.

  Run this script as admin in your demoX account.
  Should only be run once for initial setup.

  Author:   Alan Eldridge
  Updated:  16 July 2019 (mtessari): now roles are not recreated if they exist

  #admin #setup
--------------------------------------------------------------------------------*/

-- IMPORTANT!!!
-- edit the following line to set the password for John and Jane
set pwd = 'xxxxxx';

use role accountadmin;

-- create roles
create role if not exists dba_citibike comment = "Database administration";
create role if not exists analyst_citibike comment = "Business analyst & Tableau user";

grant create warehouse on account to role dba_citibike;
grant create warehouse on account to role analyst_citibike;
grant create database on account to role dba_citibike;
grant create share on account to role dba_citibike;
grant monitor usage on account to role dba_citibike;

grant role dba_citibike to role accountadmin;
grant role analyst_citibike to role accountadmin;
grant role dba_citibike to role sysadmin;
grant role analyst_citibike to role sysadmin;

-- create users
create or replace user john password=$pwd email='john@snowflakedemo.com' comment='John the DBA';
create or replace user jane password=$pwd email='jane@snowflakedemo.com' comment='Jane the marketing analyst';

grant role dba_citibike to user john;
grant role sysadmin to user john;
grant role accountadmin to user john;
alter user john set default_role=dba_citibike;

grant role analyst_citibike to user jane;
alter user jane set default_role=analyst_citibike;

-- map the reset DB from the share
create or replace database citibike_reset_v2 from share citibike_sfc.citibike_reset_v2
  comment='Reset DB for Citibike demo.';

create or replace database citibike_big_v2 from share citibike_sfc.citibike_big_v2
  comment='A bigger version of Citibike - ~1Bn trips and 600K weather records.';

grant imported privileges on database citibike_reset_v2 to role dba_citibike;
grant imported privileges on database citibike_big_v2 to role dba_citibike;
grant imported privileges on database citibike_big_v2 to role analyst_citibike;

-- create warehouses for Jane to use in Tableau
create or replace warehouse bi_medium_wh
  with warehouse_size = 'medium'
  auto_suspend = 300
  auto_resume = true
  min_cluster_count = 1
  max_cluster_count = 5
  initially_suspended = true;

create or replace warehouse bi_large_wh
  with warehouse_size = 'xlarge'
  auto_suspend = 300
  auto_resume = true
  min_cluster_count = 1
  max_cluster_count = 5
  initially_suspended = true;

grant all on warehouse bi_medium_wh to role analyst_citibike;
grant all on warehouse bi_large_wh to role analyst_citibike;

-- if you have previously used Citibike and have a customised TWB, you will need this
-- grant all on warehouse bi_wh to role analyst_citibike;

-- create the two reader accounts
create managed account if not exists nycha
  admin_name='nycha', admin_password=$pwd,
  type=reader, COMMENT='NYCHA Citibike Reader Account';

create managed account if not exists jcha
  admin_name='jcha', admin_password=$pwd,
  type=reader, COMMENT='JCHA Citibike Reader Account';

-- check results
show roles;
show users;
show warehouses;
show managed accounts;
